
var of =
document.getElementById("off");

of.onclick = function(){
alert('cert has been expired join telegram for more ')    
}





